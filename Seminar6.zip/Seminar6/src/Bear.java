public class Bear implements Animal{
    public Bear(){
        System.out.println("Este o urs");
    }
}
