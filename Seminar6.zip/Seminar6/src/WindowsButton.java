public class WindowsButton implements Button{
    public WindowsButton(){
        System.out.println("Ati apasat butonul Windows");
    }
}
