public class MacMenu implements Menu{
    public MacMenu(){
        System.out.println("Ati apasat butonul Windows");
    }
}
