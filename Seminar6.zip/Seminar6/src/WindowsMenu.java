public class WindowsMenu implements Menu{
    public WindowsMenu(){
        System.out.println("Ati apasat butonul WindowsMenu");
    }
}
