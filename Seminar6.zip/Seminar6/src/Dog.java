public class Dog implements Animal{

    public Dog(){
        System.out.println("Este un caine");
    }
}
