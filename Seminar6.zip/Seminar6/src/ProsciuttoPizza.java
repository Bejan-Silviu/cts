public class ProsciuttoPizza implements Pizza{

        public void descriere(){
            System.out.println("Este o pizza cu Prosciutto");
        }


}
