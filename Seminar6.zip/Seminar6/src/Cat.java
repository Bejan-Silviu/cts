public class Cat implements Animal{
   public Cat(){
       System.out.println("Este o pisica");
   }
}
