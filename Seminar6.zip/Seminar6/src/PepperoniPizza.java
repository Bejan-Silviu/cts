public class PepperoniPizza implements Pizza{
    public void descriere(){
        System.out.println("Este o pizza cu Pepperoni");
    }
}
