public class Main {
    public static void main(String[] args) {
        PizzaFactory.createPizza("Pepperoni").descriere();
        PizzaFactory.createPizza("Cheese").descriere();
        PizzaFactory.createPizza("Prosciutto").descriere();

        AnimalFactory af1,af2,af3;
        af1=new DogFactory();
        af1.createAnimal();

        af2=new CatFactory();
        af2.createAnimal();

        af3=new BearFactory();
        af3.createAnimal();

        WindowsGUIFactory wgf1,wgf2;

        wgf1=new WindowsGUIFactory();
        wgf1.createButton();
        wgf1.createMenu();

        MacGUIFactory mgf1,mgf2;

        mgf1=new MacGUIFactory();
        mgf1.createButton();
        mgf1.createMenu();


    }
}