public class MacButton implements Button{
    public MacButton(){
        System.out.println("Ati apasat butonul Mac");
    }
}
