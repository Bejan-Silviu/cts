public class Main {
    public static void main(String[] args) {
        Burger burger=Burger.builder().build();
        burger.setCarne("Vita");

        System.out.println(burger);
    }
}
