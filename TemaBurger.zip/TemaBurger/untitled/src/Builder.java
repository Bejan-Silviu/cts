public interface Builder {
    Burger build();
}
