public class RegularCar implements Car{
    @Override
    public String getDescription() {
        return "Audi R8 2023";
    }

    @Override
    public double getCost() {
        return 158600;
    }
}
