public interface Car {
    public String getDescription();

    public double getCost();
}
