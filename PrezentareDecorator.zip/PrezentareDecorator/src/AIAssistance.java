public class AIAssistance extends  CarDecorator{
    public AIAssistance (Car newCar) {
        super(newCar);

    }

    public String getDescription(){
        return tempCar.getDescription()+" inteligenta artificiala ";
    }

    public double getCost(){
        return tempCar.getCost()+10000;
    }
}
