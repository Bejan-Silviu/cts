public class Main {
    public static void main(String[] args) {

        Car regularCar=new AIAssistance(new LeatherSeats(new RegularCar())) ;
        System.out.println("Optiuni: "+regularCar.getDescription());
        System.out.println("Pret: "+regularCar.getCost());
        //Putem decora si invers optiunile:
        Car regularCar2=new LeatherSeats (new AIAssistance(new RegularCar())) ;
        System.out.println("Optiuni: "+regularCar2.getDescription());
        System.out.println("Pret: "+regularCar2.getCost());
        //Daca dorim doar saune de piele:
        Car regularCar3=new LeatherSeats (new RegularCar()) ;
        System.out.println("Optiuni: "+regularCar3.getDescription());
        System.out.println("Pret: "+regularCar3.getCost());
    }
}