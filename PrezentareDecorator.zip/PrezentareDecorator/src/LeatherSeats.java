public class LeatherSeats extends  CarDecorator{
    public LeatherSeats(Car newCar) {
        super(newCar);

    }

    public String getDescription(){
        return tempCar.getDescription()+" scaune de piele ";
    }

    public double getCost(){
        return tempCar.getCost()+5000;
    }
}
