public class SubscriptionDecorator implements Subscription{

    protected Subscription subscription;

    public SubscriptionDecorator(Subscription sub)
    {
        subscription=sub;
    }
    @Override
    public String getDescription() {
            return subscription.getDescription();
    }

    @Override
    public double getPrice() {
        return subscription.getPrice();
    }
}
