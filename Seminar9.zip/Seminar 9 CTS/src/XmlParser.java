
public class XmlParser {
    public void parseXml(String xml){
        System.out.println("test");
    }
}








