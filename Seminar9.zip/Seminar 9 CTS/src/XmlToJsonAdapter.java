public class XmlToJsonAdapter extends XmlParser implements JsonParser  {


    public XmlToJsonAdapter(XmlParser xmlParser) {

    }

    @Override
    public void parseJson(String json) {
        String xml = convertJsonToXml(json);
        this.parseXml(xml);
    }

    private String convertJsonToXml(String json) {

        return json;
    }
}