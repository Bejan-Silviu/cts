public class Automobil {
    public void descriere(String descriere){

    }
}
