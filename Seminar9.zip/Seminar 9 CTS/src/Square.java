public class Square {
    public void draw(){
        System.out.println("Acesta este un patrat");
    }
}
