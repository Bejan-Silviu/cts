public class DealerAuto {
    private MasinaFamilie masinaFamilie;
    private MasinaElectrica masinaElectrica;
    private MasinaSport masinaSport;

    public DealerAuto(){
        masinaElectrica=new MasinaElectrica("Masina electrica");
        masinaSport=new MasinaSport("Masina sport");
        masinaFamilie=new MasinaFamilie("Masina familie");
    }
    public void afiseazaMasiniElectrice(){
        masinaElectrica.descriere();
    }
    public void afiseazaMasiniSport(){
        masinaSport.descriere();
    }
    public void afiseazaMasiniFamilie(){
        masinaFamilie.descriere();
    }
}
