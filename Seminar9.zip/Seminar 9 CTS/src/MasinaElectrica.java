public class MasinaElectrica extends Automobil {
    String descriere;
    public MasinaElectrica(String descriere){
        this.descriere=descriere;
    }
    public void descriere(){
        System.out.println("Acesta este un automobil: "+descriere);
    }
}
