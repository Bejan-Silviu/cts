public class Main {
    public static void main(String[] args) {
            XmlParser xmlParser=new XmlParser();
            JsonParser jsonParser=new XmlToJsonAdapter();

            ShapeMaker shapeMaker=new ShapeMaker();
           shapeMaker.drawRectangle();

           DealerAuto dealerAuto=new DealerAuto();
           dealerAuto.afiseazaMasiniElectrice();
    }
}