public class Rectangle {
    public void draw(){
        System.out.println("Acesta este un dreptunghi");
    }
}
