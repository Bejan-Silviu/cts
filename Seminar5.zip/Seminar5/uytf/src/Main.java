public class Main {
    public static void main(String[] args) {
        Server x=Server.getInstance();
        //Server y=new Server(); nu functioneaza, constructorul este privat
        System.out.println(x.showStatus());

    }
    // Clasa exercitiu:
    //O fabrica de masini caer implemententeaza un sistem centralizat de monitorizare a productei. Sistemul trebuie sa asigure adaugarea modificarea datelor despre
    //masinile fabricate la nivelul sediului central, intr-un mediu securizat( sistemul va exista sub forma unui server dispis in datacenter-ul din HQ))
    // Programul trebuie sa asigure ca sistemul nu va putea fi replicat si ca toate datele vor fi manageriate prin singurului server mentionat anterior
}