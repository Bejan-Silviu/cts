public class SistemServer {
    String numeMasina="";
    int serieMasina=0;
    private static SistemServer instance;
    private SistemServer(){

    }
    private SistemServer(String numeMasina,int serieMasina){
        this.numeMasina= numeMasina;
        this.serieMasina=serieMasina;
    }
    public static SistemServer getInstance(){
        if(SistemServer.instance==null){
            SistemServer.instance=new SistemServer();
            return SistemServer.instance;


        }else{
            return SistemServer.instance;
        }

    }
    public static void setInstance(String numeMasina, int serieMasina){
        SistemServer.instance.numeMasina=numeMasina;
        SistemServer.instance.serieMasina=serieMasina;

    }

}
