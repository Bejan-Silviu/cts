public class Vehicle {
    private double value;
    public double getValue(){
        return value;
    }
}
